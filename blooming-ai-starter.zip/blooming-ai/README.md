# Blooming AI

A responsive starter interface for an all-purpose AI writing workspace.

## Run locally
1. Install Node.js (LTS).
2. In this folder, run `npm install`.
3. Run `npm run dev`.

## Deploy on Netlify
- Build command: `npm run build`
- Publish directory: `dist`

## Important
This is the frontend foundation only. AI generation, authentication, database storage, subscriptions and payments are not connected yet. API keys must be kept server-side (for example, in Netlify Functions and Netlify environment variables), never in browser code.
