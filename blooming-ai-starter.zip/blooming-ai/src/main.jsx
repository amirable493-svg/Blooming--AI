import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import { Sparkles, Feather, BookOpen, BriefcaseBusiness, GraduationCap, Megaphone, FileText, Library, Crown, Menu, ArrowUpRight, PenLine, WandSparkles } from "lucide-react";
import "./style.css";

const categories = [
  { name: "Stories & novels", detail: "Fiction, chapters, characters and plots", icon: BookOpen },
  { name: "Business writing", detail: "Proposals, descriptions and brand stories", icon: BriefcaseBusiness },
  { name: "Academic writing", detail: "Essays, reports and presentations", icon: GraduationCap },
  { name: "Marketing content", detail: "Ad copy, campaigns and social posts", icon: Megaphone },
  { name: "Articles & blogs", detail: "Helpful, engaging long-form content", icon: FileText },
  { name: "Everyday writing", detail: "Letters, biographies and personal writing", icon: Feather }
];

function App() {
  const [mode, setMode] = useState("Create");
  const [category, setCategory] = useState("Stories & novels");
  const [prompt, setPrompt] = useState("");
  const [notice, setNotice] = useState("");

  function handleStart() {
    if (!prompt.trim()) {
      setNotice("Add a little detail about what you want to write first.");
      return;
    }
    setNotice("Your workspace is ready for the next step. AI generation will be connected after we set up the secure backend.");
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <a className="brand" href="#"><span className="brand-mark"><Sparkles size={20}/></span><span>Blooming<span className="brand-ai"> AI</span></span></a>
        <p className="side-label">WORKSPACE</p>
        <a className="nav-item active" href="#"><PenLine size={18}/> Writing studio</a>
        <a className="nav-item" href="#library"><Library size={18}/> My library</a>
        <div className="side-bottom">
          <div className="premium-card">
            <Crown size={19}/>
            <strong>Blooming Premium</strong>
            <p>More room for your ideas to grow.</p>
            <span>Explore plans <ArrowUpRight size={14}/></span>
          </div>
          <div className="profile"><div className="avatar">B</div><div><strong>Welcome</strong><small>Your writing space</small></div></div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="mobile-brand"><span className="brand-mark"><Sparkles size={18}/></span> Blooming AI</div>
          <span className="top-note">A little idea can become something wonderful.</span>
          <button className="account-button">Sign in / Create account</button>
        </header>

        <section className="hero">
          <div className="eyebrow"><Sparkles size={15}/> YOUR IDEAS, WITH ROOM TO GROW</div>
          <h1>What would you like<br/><em>to create today?</em></h1>
          <p>Bring the idea. We'll help you find the words.</p>
        </section>

        <section className="studio-card">
          <div className="mode-switch" role="tablist" aria-label="Writing mode">
            <button className={mode === "Create" ? "selected" : ""} onClick={() => setMode("Create")}><WandSparkles size={16}/> Create for me</button>
            <button className={mode === "Improve" ? "selected" : ""} onClick={() => setMode("Improve")}><PenLine size={16}/> Help me improve</button>
          </div>
          <label className="field-label">{mode === "Create" ? "WHAT WOULD YOU LIKE TO WRITE?" : "PASTE WHAT YOU HAVE SO FAR"}</label>
          <textarea value={prompt} onChange={e => {setPrompt(e.target.value); setNotice("");}} placeholder={mode === "Create" ? "Describe your idea… For example: Write a warm, uplifting short story about a woman starting a new chapter in life." : "Paste your writing here. Tell us what you would like to improve…"} />
          <div className="studio-footer">
            <span><span className="status-dot"></span> Your ideas stay yours</span>
            <button className="primary-button" onClick={handleStart}>Continue <ArrowUpRight size={17}/></button>
          </div>
          {notice && <p className="notice" role="status">{notice}</p>}
        </section>

        <section className="category-section">
          <div className="section-heading"><div><span className="eyebrow">FIND YOUR STARTING POINT</span><h2>What are we working on?</h2></div><span className="small-muted">Choose a writing type</span></div>
          <div className="category-grid">
            {categories.map(({name, detail, icon: Icon}) => (
              <button key={name} className={`category-card ${category === name ? "chosen" : ""}`} onClick={() => setCategory(name)}>
                <span className="category-icon"><Icon size={20}/></span><span className="category-copy"><strong>{name}</strong><small>{detail}</small></span><ArrowUpRight className="card-arrow" size={16}/>
              </button>
            ))}
          </div>
        </section>

        <footer id="library"><span>Blooming AI</span><span>Think it. Write it. Let it bloom.</span></footer>
      </main>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
